package org.uispec4j.interception;

public class InterceptionError extends Error {
  public InterceptionError(String message, Throwable cause) {
    super(message, cause);
  }
}
