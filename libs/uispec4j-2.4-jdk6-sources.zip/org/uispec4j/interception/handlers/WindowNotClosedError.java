package org.uispec4j.interception.handlers;

public class WindowNotClosedError extends Error {
  public WindowNotClosedError(String message) {
    super(message);
  }
}
